defineComponent(function(html) {
    return {
        template: html
    }
})
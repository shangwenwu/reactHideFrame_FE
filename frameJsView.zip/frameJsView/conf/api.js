define(function() {
    //方便统一管理接口地址
    let rootUrl = 'http://globalbss-api.test.yunshanmeicai.com/';
    window.Api = {
        getinfo: rootUrl + 'foundation/userrequest/getinfo'
    }
})
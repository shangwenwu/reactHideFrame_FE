define(function() {

    //真实数据 与 虚拟数据 转换配置
    window.real = false;

    window.defaultData = {
        getinfo: {
            ret: 1,
            data: {
                user: 'shangwenwu',
                mobild: '15110289267'
            }
        }
    }

})